# ems
Employee management system using django and django rest framework

currently only api is made 
