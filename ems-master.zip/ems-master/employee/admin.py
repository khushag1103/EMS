from django.contrib import admin

from employee.models import Department, Employee

admin.site.register(Department)
admin.site.register(Employee)

